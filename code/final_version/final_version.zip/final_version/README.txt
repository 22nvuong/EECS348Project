Use the 'make build' target to compile and run the calculator.
Use the 'make clean' target to delete program.