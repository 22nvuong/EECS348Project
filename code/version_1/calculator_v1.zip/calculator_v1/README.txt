1: Compile MainTest to test data files
"g++ -std=c++11 main.cpp -o my_program"

2: Running the calculator
./my_program 

